from django.contrib import admin
from appjob.models import *
# Register your models here.

admin.site.register(JOBS),
admin.site.register(create)
